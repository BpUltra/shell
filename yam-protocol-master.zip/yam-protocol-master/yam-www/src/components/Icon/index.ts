export { default } from './Icon'
export type { IconProps } from './Icon'